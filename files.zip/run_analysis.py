"""
============================================================
  SQL Grocery Demand Analytics
  Synthetic Dataset Generator + SQL-Driven Analysis
============================================================
  Uses SQLite (stdlib) — no external DB required.
  All analysis is done in pure SQL via pandas + sqlite3.
============================================================
"""

import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from faker import Faker
import random
from datetime import date, timedelta

fake   = Faker('en_IN')
np.random.seed(42)
random.seed(42)

DB_PATH = "grocery_analytics.db"


# ─────────────────────────────────────────────────────────
#  STEP 1 — GENERATE SYNTHETIC DATASET
# ─────────────────────────────────────────────────────────

def generate_dataset():
    print("=" * 55)
    print("  SQL Grocery Demand Analytics")
    print("=" * 55)
    print("\n[1/4] Generating synthetic retail dataset...")

    conn = sqlite3.connect(DB_PATH)
    cur  = conn.cursor()

    # Drop and recreate tables
    cur.executescript("""
        DROP TABLE IF EXISTS transactions;
        DROP TABLE IF EXISTS inventory;
        DROP TABLE IF EXISTS suppliers;
        DROP TABLE IF EXISTS products;
        DROP TABLE IF EXISTS stores;

        CREATE TABLE stores (
            store_id    INTEGER PRIMARY KEY,
            location    TEXT,
            region      TEXT,
            store_type  TEXT
        );

        CREATE TABLE products (
            product_id   INTEGER PRIMARY KEY,
            name         TEXT,
            category     TEXT,
            unit_cost    REAL,
            unit_price   REAL,
            shelf_life_days INTEGER
        );

        CREATE TABLE suppliers (
            supplier_id   INTEGER,
            product_id    INTEGER,
            lead_time_days INTEGER,
            min_order_qty INTEGER,
            PRIMARY KEY (supplier_id, product_id)
        );

        CREATE TABLE transactions (
            txn_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id  INTEGER,
            store_id    INTEGER,
            date        TEXT,
            quantity_sold INTEGER,
            revenue     REAL
        );

        CREATE TABLE inventory (
            record_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id   INTEGER,
            store_id     INTEGER,
            date         TEXT,
            stock_level  INTEGER,
            reorder_point INTEGER
        );
    """)

    # Insert stores
    store_data = [
        (1, 'Connaught Place', 'North',  'Flagship'),
        (2, 'Lajpat Nagar',   'South',  'Standard'),
        (3, 'Rohini',         'North',  'Express'),
        (4, 'Dwarka',         'West',   'Standard'),
        (5, 'Noida Sector 18','East',   'Flagship'),
    ]
    cur.executemany("INSERT INTO stores VALUES (?,?,?,?)", store_data)

    # Insert products
    products = [
        (1,  'Basmati Rice 5kg',      'Staples',    180, 220, 365),
        (2,  'Whole Wheat Atta 10kg', 'Staples',    290, 340, 180),
        (3,  'Toor Dal 1kg',          'Pulses',      95, 125, 365),
        (4,  'Amul Butter 500g',      'Dairy',      220, 265, 30),
        (5,  'Full Cream Milk 1L',    'Dairy',       55,  70, 5),
        (6,  'Tomatoes 1kg',          'Vegetables',  30,  45, 5),
        (7,  'Onions 1kg',            'Vegetables',  25,  38, 14),
        (8,  'Bananas dozen',         'Fruits',      40,  60, 5),
        (9,  'Sunflower Oil 1L',      'Edible Oil', 130, 155, 365),
        (10, 'Maggi 12-pack',         'Packaged',   120, 148, 180),
        (11, 'Biscuits Assorted',     'Packaged',    80, 110, 90),
        (12, 'Detergent 1kg',         'Household',   75, 105, 730),
        (13, 'Shampoo 200ml',         'Personal',    95, 140, 730),
        (14, 'Chicken 1kg',           'Meat',       180, 230, 2),
        (15, 'Paneer 200g',           'Dairy',       60,  90, 7),
    ]
    cur.executemany("INSERT INTO products VALUES (?,?,?,?,?,?)", products)

    # Insert suppliers
    supplier_rows = []
    for pid in range(1, 16):
        sid = random.choice([101, 102, 103])
        lead = random.randint(1, 5)
        moq  = random.randint(10, 50)
        supplier_rows.append((sid, pid, lead, moq))
    cur.executemany("INSERT INTO suppliers VALUES (?,?,?,?)", supplier_rows)

    # Insert transactions (365 days × 5 stores × 15 products)
    start_date  = date(2024, 1, 1)
    txn_rows    = []
    inv_rows    = []

    for store_id in range(1, 6):
        for pid, _, category, _, unit_price, _ in products:
            base_demand = random.randint(8, 50)
            stock       = random.randint(50, 200)
            reorder_pt  = random.randint(20, 60)

            for d in range(365):
                current_date = start_date + timedelta(days=d)

                # Weekend boost
                dow_mult = 1.3 if current_date.weekday() >= 5 else 1.0

                # Category seasonality
                season_mult = 1.0
                if category in ['Vegetables', 'Fruits'] and current_date.month in [10, 11, 12]:
                    season_mult = 1.2
                if category == 'Meat' and current_date.weekday() in [5, 6]:
                    season_mult = 1.4

                qty = max(0, int(np.random.poisson(base_demand * dow_mult * season_mult)))

                # Occasionally stockout
                if stock < qty:
                    qty = stock

                revenue = round(qty * unit_price, 2)
                stock   = max(0, stock - qty)

                txn_rows.append((pid, store_id, str(current_date), qty, revenue))

                # Restock if below reorder point
                if stock <= reorder_pt:
                    stock += random.randint(50, 150)

                inv_rows.append((pid, store_id, str(current_date), stock, reorder_pt))

    cur.executemany(
        "INSERT INTO transactions (product_id,store_id,date,quantity_sold,revenue) VALUES (?,?,?,?,?)",
        txn_rows
    )
    cur.executemany(
        "INSERT INTO inventory (product_id,store_id,date,stock_level,reorder_point) VALUES (?,?,?,?,?)",
        inv_rows
    )

    conn.commit()
    print(f"      Transactions inserted : {len(txn_rows):,}")
    print(f"      Inventory records     : {len(inv_rows):,}")
    return conn


# ─────────────────────────────────────────────────────────
#  STEP 2 — SQL ANALYSES
# ─────────────────────────────────────────────────────────

def run_analyses(conn):
    print("\n[2/4] Running SQL analyses...\n")

    # ── Analysis 1: Top products by revenue ──────────────
    q1 = """
        SELECT
            p.name,
            p.category,
            ROUND(SUM(t.revenue), 0)        AS total_revenue,
            SUM(t.quantity_sold)             AS total_qty,
            ROUND(AVG(t.quantity_sold), 1)   AS avg_daily_qty
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        GROUP BY t.product_id
        ORDER BY total_revenue DESC
        LIMIT 10;
    """
    df_top = pd.read_sql_query(q1, conn)
    print("  ── Top 10 Products by Revenue ──")
    print(df_top.to_string(index=False))

    # ── Analysis 2: Day-of-week demand patterns ──────────
    q2 = """
        SELECT
            p.category,
            CASE CAST(strftime('%w', t.date) AS INTEGER)
                WHEN 0 THEN 'Sun' WHEN 1 THEN 'Mon' WHEN 2 THEN 'Tue'
                WHEN 3 THEN 'Wed' WHEN 4 THEN 'Thu' WHEN 5 THEN 'Fri'
                WHEN 6 THEN 'Sat'
            END AS day_of_week,
            ROUND(AVG(t.quantity_sold), 2) AS avg_demand
        FROM transactions t
        JOIN products p ON t.product_id = p.product_id
        GROUP BY p.category, day_of_week
        ORDER BY p.category, avg_demand DESC;
    """
    df_dow = pd.read_sql_query(q2, conn)
    print("\n  ── Day-of-Week Demand by Category ──")
    print(df_dow.head(20).to_string(index=False))

    # ── Analysis 3: Stockout risk ─────────────────────────
    q3 = """
        SELECT
            p.name,
            i.store_id,
            i.stock_level,
            i.reorder_point,
            s.lead_time_days,
            CASE
                WHEN i.stock_level <= i.reorder_point       THEN 'REORDER NOW'
                WHEN i.stock_level <= i.reorder_point * 1.2 THEN 'LOW STOCK'
                ELSE 'OK'
            END AS stock_status
        FROM inventory i
        JOIN products p  ON i.product_id = p.product_id
        JOIN suppliers s ON s.product_id = i.product_id
        WHERE i.date = (SELECT MAX(date) FROM inventory)
        ORDER BY stock_status, i.stock_level ASC
        LIMIT 15;
    """
    df_stock = pd.read_sql_query(q3, conn)
    print("\n  ── Stockout Risk (latest date) ──")
    print(df_stock.to_string(index=False))

    # ── Analysis 4: Revenue by store ─────────────────────
    q4 = """
        SELECT
            s.location,
            s.store_type,
            ROUND(SUM(t.revenue), 0)       AS total_revenue,
            ROUND(AVG(t.revenue), 2)       AS avg_daily_revenue,
            COUNT(DISTINCT t.date)         AS trading_days
        FROM transactions t
        JOIN stores s ON t.store_id = s.store_id
        GROUP BY t.store_id
        ORDER BY total_revenue DESC;
    """
    df_store = pd.read_sql_query(q4, conn)
    print("\n  ── Revenue by Store ──")
    print(df_store.to_string(index=False))

    # ── Analysis 5: Monthly trend ─────────────────────────
    q5 = """
        SELECT
            strftime('%Y-%m', t.date) AS month,
            ROUND(SUM(t.revenue), 0)  AS monthly_revenue,
            SUM(t.quantity_sold)      AS monthly_qty
        FROM transactions t
        GROUP BY month
        ORDER BY month;
    """
    df_monthly = pd.read_sql_query(q5, conn)

    return df_top, df_dow, df_store, df_monthly


# ─────────────────────────────────────────────────────────
#  STEP 3 — CHARTS
# ─────────────────────────────────────────────────────────

def plot_results(df_top, df_dow, df_store, df_monthly):
    print("\n[3/4] Generating charts...")

    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    fig.suptitle("SQL Grocery Demand Analytics — Dashboard", fontsize=14, fontweight='bold')

    # Chart 1: Top products by revenue
    axes[0,0].barh(df_top['name'][::-1], df_top['total_revenue'][::-1] / 1000,
                   color='#4c72b0')
    axes[0,0].set_title("Top 10 Products — Total Revenue (₹K)")
    axes[0,0].set_xlabel("Revenue (₹ thousands)")

    # Chart 2: Monthly revenue trend
    axes[0,1].plot(df_monthly['month'], df_monthly['monthly_revenue'] / 1_000,
                   marker='o', color='#1a7a3c', linewidth=2)
    axes[0,1].set_title("Monthly Revenue Trend (₹K)")
    axes[0,1].set_xlabel("Month")
    axes[0,1].tick_params(axis='x', rotation=45)
    axes[0,1].grid(True, alpha=0.3)

    # Chart 3: Revenue by store
    axes[1,0].bar(df_store['location'], df_store['total_revenue'] / 1_000,
                  color=['#1a7a3c','#28a745','#4c72b0','#ffc107','#dd8452'])
    axes[1,0].set_title("Total Revenue by Store (₹K)")
    axes[1,0].set_ylabel("Revenue (₹ thousands)")
    axes[1,0].tick_params(axis='x', rotation=15)

    # Chart 4: Category share of qty
    cat_qty = df_top.groupby('category')['total_qty'].sum()
    axes[1,1].pie(cat_qty, labels=cat_qty.index, autopct='%1.1f%%',
                  colors=['#4c72b0','#dd8452','#55a868','#c44e52','#8172b2','#937860'])
    axes[1,1].set_title("Sales Volume by Category")

    plt.tight_layout()
    plt.savefig('grocery_analytics_dashboard.png', dpi=150, bbox_inches='tight')
    plt.show()
    print("      Chart saved as grocery_analytics_dashboard.png")


# ─────────────────────────────────────────────────────────
#  STEP 4 — INSIGHTS SUMMARY
# ─────────────────────────────────────────────────────────

def print_insights(conn):
    print("\n[4/4] Key Insights\n")
    print("  " + "=" * 50)

    # Weekend uplift
    q = """
        SELECT
            CASE WHEN CAST(strftime('%w', date) AS INTEGER) IN (0,6)
                 THEN 'Weekend' ELSE 'Weekday' END AS period,
            ROUND(AVG(quantity_sold), 2) AS avg_qty
        FROM transactions
        GROUP BY period;
    """
    df = pd.read_sql_query(q, conn)
    wknd = df[df['period']=='Weekend']['avg_qty'].values[0]
    wkdy = df[df['period']=='Weekday']['avg_qty'].values[0]
    print(f"  📈 Weekend demand is {(wknd/wkdy - 1)*100:.1f}% higher than weekday average")

    # Stockout estimate
    q2 = """
        SELECT ROUND(SUM(t.revenue), 0) AS lost_rev
        FROM transactions t
        JOIN inventory i ON i.product_id = t.product_id
                        AND i.store_id   = t.store_id
                        AND i.date       = t.date
        WHERE i.stock_level = 0;
    """
    df2 = pd.read_sql_query(q2, conn)
    print(f"  💸 Estimated revenue lost to stockouts: ₹{df2['lost_rev'].values[0]:,.0f}")

    # Top category
    q3 = """
        SELECT p.category, ROUND(SUM(t.revenue),0) AS rev
        FROM transactions t JOIN products p ON t.product_id=p.product_id
        GROUP BY p.category ORDER BY rev DESC LIMIT 1;
    """
    df3 = pd.read_sql_query(q3, conn)
    print(f"  🏆 Highest revenue category: {df3['category'].values[0]} (₹{df3['rev'].values[0]:,.0f})")
    print("  " + "=" * 50)
    print("\n  ✅ Analysis complete. DB saved as grocery_analytics.db")


# ─────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────

if __name__ == "__main__":
    conn = generate_dataset()
    df_top, df_dow, df_store, df_monthly = run_analyses(conn)
    plot_results(df_top, df_dow, df_store, df_monthly)
    print_insights(conn)
    conn.close()
