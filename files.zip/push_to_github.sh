#!/bin/bash
# ============================================================
#  RiaMalhotra_Profile — One-Command GitHub Push
#  Run this once from the folder containing RiaMalhotra_Profile
# ============================================================

set -e

REPO_URL="https://github.com/MRia5/RiaMalhotra_Profile.git"

echo ""
echo "🚀 Pushing RiaMalhotra_Profile to GitHub..."
echo ""

cd RiaMalhotra_Profile

git init
git add .
git commit -m "feat: complete profile — README + 5 project READMEs + source code"
git branch -M main

# Remove remote if already exists (safe to re-run)
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"

git push -u origin main --force

echo ""
echo "✅ Done! Your profile repo is live at:"
echo "   https://github.com/MRia5/RiaMalhotra_Profile"
echo ""
echo "Next steps:"
echo "  1. Go to https://github.com/new"
echo "  2. Create repo named exactly: MRia5  (your username)"
echo "  3. Copy README.md content into that repo — it becomes your profile page"
